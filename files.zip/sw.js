// Loftify Service Worker — v1.0
const CACHE = 'loftify-v1';
const ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  'https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap',
];

// Install: cache app shell
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(ASSETS.map(url => {
      return new Request(url, { mode: 'no-cors' });
    }))).catch(() => {}) // Don't fail install if some assets are unavailable
  );
  self.skipWaiting();
});

// Activate: clean old caches
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Fetch: network-first for API, cache-first for assets
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);

  // Skip non-GET and chrome-extension requests
  if (e.request.method !== 'GET') return;
  if (url.protocol === 'chrome-extension:') return;

  // Jamendo API & audio — network only (don't cache audio files, too large)
  if (url.hostname.includes('jamendo') || url.hostname.includes('soundhelix') || url.hostname.includes('lyrics.ovh')) {
    e.respondWith(
      fetch(e.request).catch(() => new Response(JSON.stringify({results:[]}), {
        headers: {'Content-Type': 'application/json'}
      }))
    );
    return;
  }

  // Google Fonts — cache first
  if (url.hostname.includes('fonts')) {
    e.respondWith(
      caches.match(e.request).then(cached => cached || fetch(e.request).then(res => {
        const clone = res.clone();
        caches.open(CACHE).then(c => c.put(e.request, clone));
        return res;
      }).catch(() => cached))
    );
    return;
  }

  // App shell — cache first, then network
  e.respondWith(
    caches.match(e.request).then(cached => {
      const networkFetch = fetch(e.request).then(res => {
        if (res.ok) {
          const clone = res.clone();
          caches.open(CACHE).then(c => c.put(e.request, clone));
        }
        return res;
      });
      return cached || networkFetch;
    }).catch(() => caches.match('/index.html'))
  );
});
