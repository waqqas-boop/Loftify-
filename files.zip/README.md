# 🎵 Loftify – Free Music Streaming App

> All premium music features, completely free. No ads, no subscription, no limits.

**Live Demo**: Deploy to Cloudflare Pages for free in 5 minutes.

---

## ✨ Features

| Feature | Status |
|---------|--------|
| 🎵 Real Music Playback | ✅ Via Jamendo API (CC-licensed) |
| 🔍 Live Search | ✅ Search millions of tracks |
| 🚫 Zero Ads | ✅ Always free |
| ⬇️ Download Songs | ✅ Direct MP3 download |
| 🎛️ 10-Band Equalizer | ✅ Web Audio API with presets |
| 📖 Lyrics | ✅ Via lyrics.ovh free API |
| ❤️ Like Songs | ✅ Saved locally |
| 📋 Playlists | ✅ Unlimited, saved locally |
| 📊 Audio Visualizer | ✅ Real-time canvas visualizer |
| 🔀 Shuffle & Repeat | ✅ All modes |
| ⌨️ Keyboard Shortcuts | ✅ Space, Alt+→, Alt+←, M, L, S, F |
| 📱 PWA (Install as App) | ✅ Works offline |
| 🔒 Privacy Policy | ✅ Built-in |

---

## 🚀 Deploy to Cloudflare Pages (FREE)

### Method 1: GitHub + Cloudflare Pages (Recommended)

#### Step 1 — Push to GitHub

```bash
# 1. Create a new repo on github.com (name it "loftify" or anything)

# 2. Clone and push
git init
git add .
git commit -m "🎵 Loftify - Free music streaming app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/loftify.git
git push -u origin main
```

#### Step 2 — Connect to Cloudflare Pages

1. Go to [dash.cloudflare.com](https://dash.cloudflare.com)
2. Click **Pages** → **Create a project** → **Connect to Git**
3. Authorize GitHub and select your **loftify** repository
4. Build settings:
   - **Framework preset**: None
   - **Build command**: *(leave empty)*
   - **Build output directory**: `/` (or leave as default)
5. Click **Save and Deploy**

✅ **Done!** Your app is live at `https://loftify.pages.dev` (or custom domain)

---

### Method 2: Direct Upload (No GitHub)

1. Go to [dash.cloudflare.com](https://dash.cloudflare.com) → **Pages**
2. Click **Create a project** → **Direct Upload**
3. Name your project `loftify`
4. Upload all files: `index.html`, `sw.js`, `manifest.json`
5. Click **Deploy site**

✅ Done in under 2 minutes!

---

## 🎵 Music API Setup

### Current Setup (Works Out of the Box)
The app uses the **Jamendo API** with a free demo client ID (`b6747d04`).
This works immediately — no signup needed for testing!

### For Production (Recommended)
Get your own free Jamendo API key:

1. Go to [developer.jamendo.com](https://developer.jamendo.com/v3.0)
2. Click **Register** → Create a free account
3. Go to **My Apps** → **Register New Application**
4. Copy your `client_id`
5. In `index.html`, find this line and replace:
   ```javascript
   JAMENDO_ID: 'b6747d04',  // ← Replace with your client_id
   ```

**Jamendo API Limits (Free)**:
- 100,000 requests/day
- 500 requests/minute
- 5 million tracks available
- Creative Commons licensed music (free to stream & download)

---

## ⌨️ Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `Space` | Play / Pause |
| `Alt + →` | Next track |
| `Alt + ←` | Previous track |
| `Alt + ↑` | Volume up |
| `Alt + ↓` | Volume down |
| `M` | Mute / Unmute |
| `L` | Like current track |
| `S` | Toggle shuffle |
| `F` | Fullscreen player |
| `Esc` | Close modals |

---

## 📁 File Structure

```
loftify/
├── index.html      # Main app (HTML + CSS + JS all-in-one)
├── sw.js           # Service Worker (offline support)
├── manifest.json   # PWA manifest (install as app)
└── README.md       # This file
```

---

## 🛠️ Tech Stack

- **Frontend**: Vanilla HTML5 + CSS3 + JavaScript (no build tools!)
- **Music API**: [Jamendo API v3](https://developer.jamendo.com/v3.0) (Creative Commons music, free)
- **Lyrics API**: [lyrics.ovh](https://api.lyrics.ovh) (free, no auth)
- **Audio Engine**: Web Audio API (native browser API)
- **Storage**: Browser LocalStorage (playlists, likes, settings)
- **Offline**: Service Worker + Cache API
- **PWA**: Web App Manifest

---

## 🔒 Privacy

Loftify is privacy-friendly:
- **No tracking pixels** or analytics
- **No account required** to use
- **All settings stored locally** on your device
- **No personal data sold** or shared
- Full privacy policy available in-app

---

## 📄 License

Loftify app code: **MIT License** — use freely.

Music streamed via Loftify is provided by [Jamendo](https://www.jamendo.com) under **Creative Commons** licenses. Each track's license is visible on Jamendo's website.

---

## 💬 Support

- Email: support@loftify.app
- Open an issue on GitHub

---

*Built with ❤️ — Free music for everyone, forever.*
